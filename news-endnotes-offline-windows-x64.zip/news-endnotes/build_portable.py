"""Build the editable Windows package from the official embeddable CPython ZIP."""

import argparse
import hashlib
import io
import tempfile
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parent
RUNTIME_NAME = 'python-3.14.10-embed-amd64.zip'
RUNTIME_SHA256 = '90905e64a840557d8c1bc4f5b74db3d7ee85e3ffb217611cac1c7813acea4159'
PACKAGE_NAME = 'news-endnotes-offline-windows-x64.zip'
APP_FILES = (
    'README.md', 'start.cmd', 'start-online.cmd', 'app.py', 'documents.py', 'engine.py',
    'library.py', 'models.py', 'test_endnotes.py', 'build_portable.py',
    'static/index.html', 'static/styles.css', 'static/app.js',
    'examples/document.txt', 'examples/sources.json',
)


def build(runtime_zip, target):
    archive_data = runtime_zip.read_bytes()
    if hashlib.sha256(archive_data).hexdigest() != RUNTIME_SHA256:
        raise ValueError(f'运行环境的 SHA-256 不符，请使用 Python 官方的 {RUNTIME_NAME}。')
    if target.resolve() == runtime_zip.resolve():
        raise ValueError('输出路径不能与官方运行环境压缩包相同。')
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent, prefix='endnotes-', suffix='.zip', delete=False) as pending:
        temporary = Path(pending.name)
    try:
        with ZipFile(io.BytesIO(archive_data)) as runtime, ZipFile(temporary, 'w', ZIP_DEFLATED) as output:
            for filename in APP_FILES:
                output.write(ROOT / filename, 'news-endnotes/' + filename)
            for entry in runtime.infolist():
                data = runtime.read(entry)
                if entry.filename == 'python314._pth':
                    data = b'python314.zip\r\n.\r\n..\r\n'
                output.writestr('news-endnotes/runtime/' + entry.filename, data)
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description='构建 Windows x64 离线便携版')
    parser.add_argument('--python-zip', type=Path, default=ROOT / '.package-cache' / RUNTIME_NAME)
    parser.add_argument('--output', type=Path, default=ROOT / 'release' / PACKAGE_NAME)
    args = parser.parse_args()
    try:
        build(args.python_zip, args.output)
    except (OSError, ValueError) as error:
        parser.exit(1, f'{error}\n')
    print(args.output.resolve())
    print(f'SHA-256: {hashlib.sha256(args.output.read_bytes()).hexdigest()}')


if __name__ == '__main__':
    main()
