import argparse
import hashlib
import json
import threading
import urllib.request
import uuid
import webbrowser
from array import array
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from documents import extract_text, render_docx, render_html, report
from engine import Index, assess, can_cite, evidence_for, get_claims
from library import import_library, preview_word
from models import CompatibleModel, ModelError


ROOT = Path(__file__).resolve().parent
MAX_REQUEST = 48 * 1024 * 1024
STATIC = {
    '/': ('static/index.html', 'text/html'),
    '/styles.css': ('static/styles.css', 'text/css'),
    '/app.js': ('static/app.js', 'text/javascript'),
    '/example.json': ('examples/sources.json', 'application/json'),
    '/example.txt': ('examples/document.txt', 'text/plain'),
}
DOCX = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'


def model_for(settings, offline=False):
    if settings is None:
        return None
    if not isinstance(settings, dict) or any(not isinstance(value, str) for value in settings.values()):
        raise ValueError('模型配置格式有误。')
    return CompatibleModel(settings, offline)


class Job:
    def __init__(self, payload, offline=False):
        self.id = uuid.uuid4().hex
        self.document = extract_text(payload.get('document'))
        self.name = Path(payload['document'].get('name', 'document.txt')).name
        self.claims = get_claims(self.document)
        self.rows = {}
        self.warnings = []
        self.lock = threading.Lock()
        self.status = 'running'
        self.phase = '建立素材索引'
        self.error = None
        self.retrieval = '关键词'
        self.source_count = 0
        self.duplicate_count = 0
        self.index = None
        self.candidate_limit = payload.get('candidate_limit', 5)
        if type(self.candidate_limit) != int or not 3 <= self.candidate_limit <= 10:
            raise ValueError('每句候选数应在 3–10 之间。')
        self.configured_model = model_for(payload.get('model'), offline)
        self.model_name = self.configured_model.model if self.configured_model else None
        self.auto_accept = payload.get('auto_accept') is True
        self.library = payload.get('library_files')
        if self.library is None and isinstance(payload.get('library'), dict):
            self.library = [payload['library']]
        if not isinstance(self.library, list) or not self.library:
            raise ValueError('请导入素材库。')
        self.split_word_headings = payload.get('split_word_headings') is True
        self.word_metadata = payload.get('word_metadata')

    def run(self):
        model = self.configured_model
        try:
            sources, duplicates = import_library(self.library, self.split_word_headings, self.word_metadata)
            self.library = None
            index = Index(sources)
            if not index.windows:
                raise ValueError('素材未产生可检索的原文片段。')
            self.source_count = len(sources)
            self.duplicate_count = duplicates
            self.index = index
            queries = [claim['text'] for claim in self.claims]
            vectors = self.load_vectors(model, index, queries)
            self.phase = '检索与核验'
            failures = 0
            for claim, vector in zip(self.claims, vectors):
                context = claim['context'].splitlines()[-1:] or ['']
                query = claim['text'] + ' ' + context[0][-70:]
                windows = index.retrieve(query, self.candidate_limit, vector)
                row = assess(claim, index, windows, model, self.auto_accept)
                with self.lock:
                    if row.get('model_failed'):
                        failures += 1
                    elif windows:
                        failures = 0
                    if failures == 3 and model:
                        self.warnings.append('模型连续三次核验失败。余下句段按候选检索处理，供人工复核。')
                        model = None
                    self.rows[row['id']] = row
            with self.lock:
                self.phase = '可复核和导出'
                self.status = 'ready'
        except (ValueError, ModelError) as error:
            with self.lock:
                self.error = str(error)
                self.status = 'failed'
        except Exception:
            with self.lock:
                self.error = '任务出现内部错误。请检查文件格式后重新运行。'
                self.status = 'failed'
            raise
        finally:
            self.configured_model = None
            self.library = None

    def load_vectors(self, model, index, queries):
        if model and model.embedding_model:
            if len(index.windows) > 4000:
                self.warnings.append('超过 4,000 个窗口，本次采用关键词检索。')
            else:
                self.phase = '计算素材与文稿向量'
                try:
                    materials = model.embed([window.text for window in index.windows])
                    vectors = model.embed(queries)
                    if len(materials[0]) != len(vectors[0]):
                        raise ModelError('素材与文稿的向量维度不一致。')
                    index.vectors = [array('f', vector) for vector in materials]
                    self.retrieval = '关键词 + 向量'
                    return vectors
                except ModelError as error:
                    self.warnings.append(f'向量检索降级为关键词检索。{error}')
        return [None] * len(queries)

    def summary(self):
        with self.lock:
            return {
                'id': self.id, 'status': self.status, 'phase': self.phase, 'error': self.error,
                'name': self.name, 'document': self.document, 'total': len(self.claims),
                'source_count': self.source_count, 'duplicate_count': self.duplicate_count,
                'retrieval': self.retrieval, 'warnings': list(self.warnings), 'model': self.model_name,
                'rows': [{key: row[key] for key in ('id', 'text', 'status', 'reason', 'decision')}
                         for row in self.rows.values()],
            }

    def detail(self, claim_id):
        with self.lock:
            row = self.get_row(claim_id)
            return self.render_detail(row)

    def get_row(self, claim_id):
        if self.status != 'ready':
            raise ValueError('请等待任务处理完成。')
        if claim_id not in self.rows:
            raise KeyError('找不到这条陈述。')
        return self.rows[claim_id]

    def render_detail(self, row):
        return {**row, 'candidates': [self.index.windows_by_id[key].as_candidate()
                                     for key in row['candidates']]}

    def search(self, claim_id, query):
        if not isinstance(query, str) or not 0 < len(query.strip()) <= 400:
            raise ValueError('请输入不超过 400 字的检索词。')
        with self.lock:
            row = self.get_row(claim_id)
            found = [window.id for window in self.index.retrieve(query, 10)]
            previous = row['candidates']
            evidence_ids = [item['window_id'] for item in row['evidence']]
            row['candidates'] = list(dict.fromkeys(evidence_ids + found + previous))[:30]
            return {**self.render_detail(row), 'search_count': len(found)}

    def review(self, claim_id, payload):
        action = payload.get('action')
        with self.lock:
            row = self.get_row(claim_id)
            if action == 'approve':
                evidence = evidence_for(self.index, payload.get('selections'), row['candidates'])
                if not can_cite(evidence):
                    raise ValueError('请选中至少一段全文或发布方原始摘要。')
                row.update(evidence=evidence, status='approved', decision='human')
            elif action == 'dismiss':
                row.update(status='ignored', decision='human')
            elif action == 'reopen':
                row.update(status='pending', decision=None)
            else:
                raise ValueError('未知的复核操作。')
            return self.render_detail(row)

    def source_text(self, window_id):
        with self.lock:
            if self.status != 'ready' or window_id not in self.index.windows_by_id:
                raise KeyError('找不到此原文。')
            window = self.index.windows_by_id[window_id]
            return {'source': window.source.metadata(), 'text': window.source.text, 'ranges': window.sentences,
                    'locations': [window.source.locate(start, end) for start, end in window.sentences]}

    def export(self, file_format):
        with self.lock:
            if self.status != 'ready':
                raise ValueError('请等待任务处理完成后再导出。')
            rows = list(self.rows.values())
            endnotes, marks = report(self.index, self.document, rows)
            if file_format == 'docx':
                return render_docx(self.document, endnotes, marks), DOCX, 'annotated.docx'
            if file_format == 'html':
                return render_html(self.document, endnotes, marks), 'text/html', 'annotated.html'
            if file_format == 'json':
                return json_bytes({
                    'document': self.name, 'document_sha256': hashlib.sha256(self.document.encode()).hexdigest(),
                    'offset_unit': 'unicode_code_point', 'retrieval': self.retrieval, 'model': self.model_name,
                    'warnings': self.warnings, 'endnotes': endnotes, 'review': rows,
                }), 'application/json', 'citation-audit.json'
            raise KeyError('未知导出格式。')


def json_bytes(value):
    return json.dumps(value, ensure_ascii=False).encode('utf-8')


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, port, offline=True):
        super().__init__(('127.0.0.1', port), Handler)
        self.offline = offline
        self.jobs = {}
        self.jobs_lock = threading.Lock()

    def add_job(self, job):
        with self.jobs_lock:
            if any(other.status == 'running' for other in self.jobs.values()):
                raise ValueError('已有文档正在处理，请等当前任务完成。')
            while len(self.jobs) >= 5:
                self.jobs.pop(next(iter(self.jobs)))
            self.jobs[job.id] = job
        threading.Thread(target=job.run, daemon=True).start()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def reply(self, status, content, kind='application/json', attachment=None):
        self.send_response(status)
        if kind.startswith('text/') or kind == 'application/json':
            kind += '; charset=utf-8'
        self.send_header('Content-Type', kind)
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-DNS-Prefetch-Control', 'off')
        self.send_header('Content-Security-Policy',
                         "default-src 'self'; script-src 'self'; style-src 'self'; "
                         "object-src 'none'; frame-ancestors 'none'; base-uri 'none'")
        if attachment:
            self.send_header('Content-Disposition', f'attachment; filename="{attachment}"')
        self.end_headers()
        self.wfile.write(content)

    def json_reply(self, status, value):
        self.reply(status, json_bytes(value))

    def do_GET(self):
        self.handle_request('GET')

    def do_POST(self):
        self.handle_request('POST')

    def handle_request(self, method):
        try:
            port = self.server.server_address[1]
            hosts = {f'127.0.0.1:{port}', f'localhost:{port}'}
            origins = {'http://' + host for host in hosts}
            if (self.headers.get('Host') not in hosts or
                    self.headers.get('Origin') not in (origins | {None}) or
                    self.headers.get('Sec-Fetch-Site') == 'cross-site'):
                self.json_reply(403, {'error': '请在本机打开此工具。'})
                return
            path = urlsplit(self.path).path
            payload = self.read_payload() if method == 'POST' else None
            if method == 'GET' and path in STATIC:
                filename, kind = STATIC[path]
                self.reply(200, (ROOT / filename).read_bytes(), kind)
            elif method == 'GET' and path == '/api/health':
                self.json_reply(200, {'app': 'news-endnotes', 'word_sources': True, 'offline': self.server.offline})
            elif method == 'POST' and path == '/api/word-sources/preview':
                entries = preview_word(payload.get('files'), payload.get('split_word_headings') is True)
                self.json_reply(200, {'entries': entries})
            elif method == 'POST' and path == '/api/model-test':
                model = model_for(payload.get('model'), self.server.offline)
                if not model:
                    raise ValueError('当前为人工复核模式。')
                result = model.chat('只返回 JSON 对象 {"ok":true}。', {'test': '连接测试'})
                if result.get('ok') is not True:
                    raise ModelError('模型已响应，但未按要求返回 JSON。')
                if model.embedding_model:
                    model.embed(['连接测试'])
                self.json_reply(200, {'ok': True})
            elif method == 'POST' and path == '/api/jobs':
                job = Job(payload, self.server.offline)
                self.server.add_job(job)
                self.json_reply(202, {'id': job.id})
            elif path.startswith('/api/jobs/'):
                self.dispatch_job(method, path, payload)
            else:
                raise KeyError('此页面或接口不存在。')
        except KeyError as error:
            self.json_reply(404, {'error': str(error.args[0])})
        except ValueError as error:
            self.json_reply(400, {'error': str(error)})
        except ModelError as error:
            self.json_reply(502, {'error': str(error)})
        except (BrokenPipeError, ConnectionResetError):
            return

    def read_payload(self):
        if self.headers.get_content_type() != 'application/json':
            raise ValueError('接口仅接受 JSON 请求。')
        size = int(self.headers.get('Content-Length', 0))
        if not 0 < size <= MAX_REQUEST:
            raise ValueError('上传大小超出 48 MB 或请求体为空。')
        value = json.loads(self.rfile.read(size))
        if not isinstance(value, dict):
            raise ValueError('接口请求应为 JSON 对象。')
        return value

    def dispatch_job(self, method, path, payload):
        _, _, _, job_id, *parts = path.split('/')
        with self.server.jobs_lock:
            job = self.server.jobs.get(job_id)
        if job is None:
            raise KeyError('任务已过期，请重新导入。')
        if method == 'GET' and not parts:
            self.json_reply(200, job.summary())
        elif method == 'GET' and len(parts) == 2 and parts[0] == 'claims':
            self.json_reply(200, job.detail(parts[1]))
        elif method == 'GET' and len(parts) == 2 and parts[0] == 'sources':
            self.json_reply(200, job.source_text(parts[1]))
        elif method == 'GET' and len(parts) == 2 and parts[0] == 'export':
            content, kind, attachment = job.export(parts[1])
            self.reply(200, content, kind, attachment)
        elif method == 'POST' and len(parts) == 3 and parts[0] == 'claims':
            if parts[2] == 'review':
                self.json_reply(200, job.review(parts[1], payload))
            elif parts[2] == 'search':
                self.json_reply(200, job.search(parts[1], payload.get('query')))
            else:
                raise KeyError('未知复核操作。')
        else:
            raise KeyError('此接口不存在。')


def main():
    parser = argparse.ArgumentParser(description='文档尾注工具')
    parser.add_argument('--port', type=int)
    parser.add_argument('--online', action='store_true', help='允许配置远程模型 API')
    parser.add_argument('--open', action=argparse.BooleanOptionalAction, help='启动时打开默认浏览器')
    args = parser.parse_args()
    offline = not args.online
    port = args.port if args.port is not None else (8771 if offline else 8772)
    if not 0 <= port <= 65535:
        parser.error('端口应在 0–65535 之间。')
    try:
        server = Server(port, offline=offline)
    except OSError as error:
        url = f'http://127.0.0.1:{port}/'
        if args.open and existing_service(url, offline):
            webbrowser.open(url)
            return
        parser.exit(1, f'无法启动本机服务。{error}\n可用 --port 指定其他端口。\n')
    with server:
        url = f'http://127.0.0.1:{server.server_address[1]}/'
        print(f'文档尾注工具已启动。{url}', flush=True)
        if args.open:
            webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


def existing_service(url, offline):
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(url + 'api/health', timeout=1) as response:
            result = json.loads(response.read(4096))
            return (isinstance(result, dict) and result.get('app') == 'news-endnotes'
                    and result.get('word_sources') is True and result.get('offline') is offline)
    except (OSError, ValueError):
        return False


if __name__ == '__main__':
    main()
