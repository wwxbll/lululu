@echo off
call "%~dp0start.cmd" --online %*
exit /b %errorlevel%
