@echo off
setlocal
pushd "%~dp0"
set "ENDNOTES_PYTHON="

if exist "runtime\python.exe" (
    set "ENDNOTES_PYTHON=%CD%\runtime\python.exe"
    goto bundled
)

for /f "delims=" %%N in ('where node.exe 2^>nul') do (
    if exist "%%~dpN..\..\python\python.exe" set "ENDNOTES_PYTHON=%%~dpN..\..\python\python.exe"
)
if defined ENDNOTES_PYTHON goto bundled

py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto launcher

python -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto direct
echo Python 3.10 or later is required. Install it and run start.cmd again.
goto fail

:bundled
"%ENDNOTES_PYTHON%" -B -X utf8 app.py --open %*
goto done

:launcher
py -3 -B -X utf8 app.py --open %*
goto done

:direct
python -B -X utf8 app.py --open %*

:done
if errorlevel 1 goto fail
popd
exit /b 0

:fail
popd
pause
exit /b 1
