import re
from dataclasses import replace
from pathlib import PureWindowsPath

from documents import INVALID_XML, read_word
from engine import load_sources, parse_source, valid_source_url


FIELDS = {
    '标题': 'title', '题名': 'title', '来源': 'publisher', '媒体': 'publisher', '发布单位': 'publisher',
    '发布日期': 'date', '发布时间': 'date', '日期': 'date', 'url': 'url', '原文链接': 'url',
    '新闻链接': 'url', '链接': 'url', '网址': 'url',
}
METADATA_LINE = re.compile(
    r'(?:^|[｜|])\s*(' + '|'.join(FIELDS) + r')\s*[:：]\s*([^｜|\r\n]*)',
    flags=re.IGNORECASE | re.MULTILINE,
)
KEY = re.compile(r'[A-Za-z0-9_-]{1,60}\Z')


def inputs(files):
    if not isinstance(files, list) or not 1 <= len(files) <= 40:
        raise ValueError('请选择 1–40 个素材文件。')
    keys = set()
    for index, file in enumerate(files, 1):
        if not isinstance(file, dict):
            raise ValueError('素材文件格式有误。')
        name = file.get('name', '')
        key = file.get('key', f'file-{index}')
        if not isinstance(name, str) or INVALID_XML.search(name):
            raise ValueError('素材文件名无效。')
        if not isinstance(key, str) or not KEY.fullmatch(key) or key in keys:
            raise ValueError('素材文件的导入编号无效或重复。')
        keys.add(key)
        name = PureWindowsPath(name).name
        file_type = file.get('format', PureWindowsPath(name).suffix.removeprefix('.').lower() or 'json')
        if file_type not in ('docx', 'json', 'csv', 'tsv'):
            raise ValueError(f'「{name}」格式不受支持。请选择 DOCX、JSON、CSV 或 TSV。')
        yield file, name or f'素材{index}.{file_type}', file_type, key


def sections(paragraphs, split):
    first = 0
    if split:
        for index, paragraph in enumerate(paragraphs):
            if paragraph.role == 'heading' and paragraph.text.strip():
                if index > first:
                    yield paragraphs[first:index]
                first = index
    if first < len(paragraphs):
        yield paragraphs[first:]


def read_section(paragraphs, default_title):
    metadata = {}
    first = 0
    for index, paragraph in enumerate(paragraphs):
        text = paragraph.text.strip()
        if not text or text in ('正文', '正文：', '正文:'):
            first = index + 1
            if text:
                break
            continue
        matches = list(METADATA_LINE.finditer(text))
        if not metadata and not matches and len(text) <= 120:
            next_text = next((item.text.strip() for item in paragraphs[index + 1:] if item.text.strip()), '')
            assumed_title = not re.search(r'[。！？]$', text) and METADATA_LINE.match(next_text)
        else:
            assumed_title = False
        if not metadata and not matches and (paragraph.role in ('heading', 'title') or assumed_title):
            metadata['title'] = text
            first = index + 1
            continue
        if not matches or matches[0].start() != 0:
            break
        for match in matches:
            key, value = FIELDS[match[1].lower()], match[2].strip()
            if key == 'url' and not valid_source_url(value):
                value = next((link for link in paragraph.links if valid_source_url(link)), '')
            if value:
                metadata[key] = value
        first = index + 1

    body = paragraphs[first:]
    if not any(paragraph.text.strip() for paragraph in body):
        return None
    metadata.setdefault('title', default_title)
    ranges = []
    offset = 0
    for paragraph in body:
        end = offset + len(paragraph.text)
        if end > offset:
            ranges.append((offset, end, paragraph.number))
        offset = end + 1
    return metadata, '\n'.join(paragraph.text for paragraph in body), tuple(ranges)


def word_sections(file, name, key, split):
    try:
        paragraphs = read_word(file.get('base64'))
        entries = []
        for block in sections(paragraphs, split):
            parsed = read_section(block, PureWindowsPath(name).stem)
            if parsed:
                mode = 'section' if split else 'file'
                entries.append((f'{key}:{mode}-{block[0].number}', *parsed))
        if not entries:
            raise ValueError('未找到可作为素材的正文段落。')
        return entries
    except ValueError as error:
        raise ValueError(f'「{name}」：{error}') from error


def preview_word(files, split):
    entries = []
    for file, name, file_type, key in inputs(files):
        if file_type != 'docx':
            continue
        for entry_id, metadata, _, ranges in word_sections(file, name, key, split):
            entries.append({'key': entry_id, 'file_name': name, 'first_paragraph': ranges[0][2], **metadata})
    return entries


def import_library(files, split=False, overrides=None):
    if overrides is None:
        overrides = {}
    if not isinstance(overrides, dict):
        raise ValueError('Word 来源信息格式有误。')
    sources = []
    signatures = set()
    duplicates = 0
    for file, name, file_type, key in inputs(files):
        if file_type == 'docx':
            parsed = []
            for entry_id, metadata, body, ranges in word_sections(file, name, key, split):
                changes = overrides.get(entry_id, {})
                if not isinstance(changes, dict) or any(not isinstance(value, str) for value in changes.values()):
                    raise ValueError(f'「{name}」的来源信息格式有误。')
                for field in ('title', 'publisher', 'date', 'url'):
                    if field in changes:
                        metadata[field] = changes[field].strip()
                metadata['title'] = metadata.get('title') or PureWindowsPath(name).stem
                try:
                    source = parse_source({**metadata, 'id': entry_id, 'text': body}, 1, metadata_optional=True)
                except ValueError as error:
                    raise ValueError(f'「{name}」：{error}') from error
                parsed.append(replace(source, file_name=name, paragraphs=ranges))
        else:
            text = file.get('text')
            if not isinstance(text, str):
                raise ValueError(f'「{name}」未提供文本。')
            try:
                parsed, dropped = load_sources(text, file_type)
            except ValueError as error:
                raise ValueError(f'「{name}」：{error}') from error
            duplicates += dropped
            if len(files) > 1:
                parsed = [replace(source, id=f'{key}:{source.id}') for source in parsed]
        if len(sources) + duplicates + len(parsed) > 5000:
            raise ValueError('每次最多导入 5,000 条素材。')
        for source in parsed:
            signature = source.digest, source.kind
            if signature in signatures:
                duplicates += 1
                continue
            sources.append(source)
            signatures.add(signature)
    return sources, duplicates
