import json
import math
import re
import urllib.error
import urllib.request
from urllib.parse import urlsplit


class ModelError(Exception):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class CompatibleModel:
    """Adapter for OpenAI-compatible local servers and hosted APIs."""

    def __init__(self, settings, offline=False):
        base_url = settings.get('base_url', '').strip().rstrip('/')
        if base_url.endswith('/chat/completions'):
            base_url = base_url.removesuffix('/chat/completions')
        try:
            url = urlsplit(base_url)
            local = url.hostname in ('localhost', '127.0.0.1', '::1')
            if not url.hostname or url.username or url.password or url.query or url.fragment:
                raise ValueError()
            if url.scheme != 'https' and not (local and url.scheme == 'http'):
                raise ValueError()
            if url.port == 0:
                raise ValueError()
        except ValueError as error:
            raise ValueError('请填写有效的 API 地址。本机可用 HTTP，远程请用 HTTPS。') from error
        if offline:
            if not local:
                raise ValueError('离线模式仅允许连接本机模型。请输入 127.0.0.1 或 localhost 地址。')
            host = '[::1]' if url.hostname == '::1' else '127.0.0.1'
            port = f':{url.port}' if url.port is not None else ''
            base_url = url._replace(netloc=host + port).geturl()
        self.base_url = base_url
        self.model = settings.get('model', '').strip()
        self.embedding_model = settings.get('embedding_model', '').strip()
        if not self.model:
            raise ValueError('请填写对话模型名称。')
        self.headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        key = settings.get('api_key', '').strip()
        if key:
            if any(not 32 < ord(character) < 127 for character in key):
                raise ValueError('API 密钥应为单行 ASCII 字符。')
            self.headers['Authorization'] = 'Bearer ' + key
        proxy = urllib.request.ProxyHandler({}) if local else urllib.request.ProxyHandler()
        self.opener = urllib.request.build_opener(proxy, NoRedirect())

    def post(self, endpoint, payload):
        request = urllib.request.Request(
            self.base_url + endpoint, json.dumps(payload, ensure_ascii=False).encode('utf-8'),
            self.headers, method='POST',
        )
        try:
            with self.opener.open(request, timeout=120) as response:
                data = json.loads(response.read(8 * 1024 * 1024 + 1))
        except urllib.error.HTTPError as error:
            raise ModelError(f'模型服务返回 HTTP {error.code}。请检查地址、模型名、密钥和额度。') from error
        except (OSError, ValueError, UnicodeError) as error:
            raise ModelError('模型服务连接失败、超时或返回了无效响应。') from error
        if not isinstance(data, dict):
            raise ModelError('模型服务没有返回 JSON 对象。')
        return data

    def chat(self, instructions, data):
        response = self.post('/chat/completions', {
            'model': self.model,
            'messages': [
                {'role': 'system', 'content': instructions},
                {'role': 'user', 'content': json.dumps(data, ensure_ascii=False)},
            ],
        })
        try:
            content = response['choices'][0]['message']['content'].strip()
            content = re.sub(r'^<think>.*?</think>\s*', '', content, count=1, flags=re.S)
            fenced = re.fullmatch(r'```(?:json)?\s*(.*?)\s*```', content, flags=re.S | re.I)
            result = json.loads(fenced[1] if fenced else content)
        except (KeyError, ValueError, AttributeError, IndexError, TypeError) as error:
            raise ModelError('模型输出不是所需的 JSON。可换用遵循指令较好的模型。') from error
        if not isinstance(result, dict):
            raise ModelError('模型输出应为 JSON 对象。')
        return result

    def embed(self, texts):
        vectors = []
        for start in range(0, len(texts), 32):
            batch = texts[start:start + 32]
            response = self.post('/embeddings', {'model': self.embedding_model, 'input': batch})
            try:
                items = sorted(response['data'], key=lambda item: item['index'])
                if [item['index'] for item in items] != list(range(len(batch))):
                    raise ValueError()
                for item in items:
                    vector = [float(value) for value in item['embedding']]
                    norm = math.sqrt(sum(value * value for value in vector))
                    if not norm or not math.isfinite(norm) or (vectors and len(vector) != len(vectors[0])):
                        raise ValueError()
                    vectors.append([value / norm for value in vector])
            except (KeyError, ValueError, OverflowError, TypeError) as error:
                raise ModelError('Embedding 服务没有返回完整、同维度的向量。') from error
        return vectors
