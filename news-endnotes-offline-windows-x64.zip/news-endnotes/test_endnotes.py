import base64
import io
import json
import threading
import time
import unittest
import urllib.error
import urllib.request
import zipfile
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from app import ROOT, Server
from documents import extract_text, render_docx, report, w
from engine import Index, assess, evidence_for, get_claims, load_sources, verify_record
from library import import_library, preview_word


LIBRARY = (ROOT / 'examples' / 'sources.json').read_text(encoding='utf-8')
CLAIM = '2025年第一季度，海州市轨道交通客运量同比增长12%。'
QUOTE = '本次统计覆盖海州市轨道交通全线网。2025年首季，全线网客运量较上年同期增加12%。'


def word_file(key, name, paragraphs):
    package = io.BytesIO()
    with zipfile.ZipFile(package, 'w') as output:
        document = ET.Element(w('document'))
        body = ET.SubElement(document, w('body'))
        for style, text in paragraphs:
            paragraph = ET.SubElement(body, w('p'))
            if style:
                props = ET.SubElement(paragraph, w('pPr'))
                ET.SubElement(props, w('pStyle'), {w('val'): style})
            ET.SubElement(ET.SubElement(paragraph, w('r')), w('t')).text = text
        output.writestr('word/document.xml', ET.tostring(document, encoding='utf-8'))
    return {'key': key, 'name': name, 'format': 'docx', 'base64': base64.b64encode(package.getvalue()).decode()}


class EngineTests(unittest.TestCase):
    def setUp(self):
        sources, _ = load_sources(LIBRARY, 'json')
        self.index = Index(sources)
        self.window = next(window for window in self.index.windows if window.text == QUOTE)
        self.selection = {'window_id': self.window.id, 'first': 1, 'last': 2}

    def test_exact_original_and_word_reference(self):
        evidence = evidence_for(self.index, [self.selection], [self.window.id])
        self.assertEqual(evidence[0]['quote'], QUOTE)
        self.assertEqual(self.window.source.text[evidence[0]['start']:evidence[0]['end']], QUOTE)

        claim, = get_claims(CLAIM)
        notes, marks = report(self.index, CLAIM, [{**claim, 'status': 'approved', 'evidence': evidence}])
        download = render_docx(CLAIM, notes, marks)
        with zipfile.ZipFile(io.BytesIO(download)) as package:
            document = ET.fromstring(package.read('word/document.xml'))
            endnotes = ET.fromstring(package.read('word/endnotes.xml'))
            ref, = document.iter(w('endnoteReference'))
            note, = endnotes.iter(w('endnote'))
            self.assertEqual(ref.get(w('id')), note.get(w('id')))
            self.assertIn(QUOTE, ''.join(note.itertext()))
        self.assertEqual(extract_text({'name': 'report.docx', 'base64': base64.b64encode(download).decode()}), CLAIM)
        with self.assertRaises(ValueError):
            verify_record(self.index, [{**evidence[0], 'quote': '篡改文字'}])

    def test_forged_window_and_invalid_ranges(self):
        for bad in [{'window_id': 'W99999'}, {'first': True}, {'last': 3}]:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                evidence_for(self.index, [{**self.selection, **bad}], [self.window.id])

    def test_forecast_cannot_be_auto_cited_as_actual(self):
        claim, = get_claims('第二季度轨道交通客运量同比增长15%。')
        forecast = next(window for window in self.index.windows if window.text.startswith('运营单位预计'))

        class ConfusedModel:
            def chat(self, _instructions, _data):
                return {'verdict': 'supports', 'reason': '数值相同', 'selections': [
                    {'window_id': forecast.id, 'first': 1, 'last': 1},
                ]}

        row = assess(claim, self.index, [forecast], ConfusedModel(), True)
        self.assertEqual(row['status'], 'suggested')
        self.assertTrue(any('预测' in flag for flag in row['flags']))

    def test_csv_quotes_and_duplicate_snapshot(self):
        data = ('编号,标题,来源,发布日期,URL,全文\r\n'
                'a,报道,媒体,2025-04-15,https://example.invalid/a,"用逗号,分隔。\r\n第二句。"\r\n'
                'b,转载,媒体,2025-04-15,https://example.invalid/b,"用逗号,分隔。\r\n第二句。"\r\n')
        sources, duplicates = load_sources(data, 'csv')
        self.assertEqual(duplicates, 1)
        self.assertEqual(sources[0].text, '用逗号,分隔。\r\n第二句。')

    def test_word_sources_preserve_coordinates_and_read_metadata(self):
        files = [
            word_file('A', '交通素材.docx', [
                ('', '轨道交通报道'), ('', '来源：海州日报｜发布日期：2025-04-15'),
                ('', '原文链接：https://example.invalid/metro'),
                ('', '本次统计覆盖海州市轨道交通全线网。'),
                ('', '2025年首季，全线网客运量较上年同期增加12%。'),
            ]),
            word_file('B', '市场素材.docx', [('', '今年首季，新增登记商户逾两千家。')]),
        ]
        preview = preview_word(files, False)
        self.assertEqual([row['first_paragraph'] for row in preview], [4, 1])
        self.assertEqual(preview[0]['title'], '轨道交通报道')
        self.assertEqual(preview[0]['url'], 'https://example.invalid/metro')
        sources, duplicates = import_library(files, overrides={preview[1]['key']: {'publisher': '市场监管局'}})
        self.assertEqual(duplicates, 0)
        self.assertEqual(sources[1].publisher, '市场监管局')
        self.assertEqual(sources[1].date, '')
        index = Index(sources)
        window = next(window for window in index.windows if window.text.replace('\n', '') == QUOTE)
        note, = evidence_for(index, [{'window_id': window.id, 'first': 1, 'last': 2}], [window.id])
        self.assertEqual(note['location'], {'file_name': '交通素材.docx', 'first_paragraph': 4, 'last_paragraph': 5})
        self.assertEqual(note['quote'], QUOTE.replace('。2025', '。\n2025'))
        self.assertEqual(verify_record(index, [note]), [note])

    def test_word_compilation_can_split_by_heading(self):
        file = word_file('A', '周报汇编.docx', [
            ('Title', '合集'), ('Heading1', '轨道交通'), ('', '客运量增加12%。'),
            ('Heading1', '市场登记'), ('', '新登记市场主体100家。'),
        ])
        combined, _ = import_library([file])
        split, _ = import_library([file], split=True)
        self.assertEqual(len(combined), 1)
        self.assertEqual([source.title for source in split], ['轨道交通', '市场登记'])
        self.assertEqual([source.text for source in split], ['客运量增加12%。', '新登记市场主体100家。'])


class ModelStub(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        self.server.calls.append((self.path, self.headers.get('Authorization')))
        if self.path == '/v1/embeddings':
            result = {'data': [{'index': index, 'embedding': [1, len(text)]}
                               for index, text in enumerate(body['input'])]}
        else:
            payload = json.loads(body['messages'][1]['content'])
            if 'test' in payload:
                answer = {'ok': True}
            elif 'excerpts' in payload:
                answer = {'supports': payload['excerpts'][0]['text'] == QUOTE, 'reason': '二次核验'}
            else:
                answer = {'verdict': 'insufficient', 'reason': '无完整证据', 'selections': []}
                for window in payload['windows']:
                    if ''.join(window['sentences'][:2]) == QUOTE:
                        answer = {'verdict': 'supports', 'reason': '两个相邻句完整支持',
                                  'selections': [{'window_id': window['id'], 'first': 1, 'last': 2}]}
                        break
            result = {'choices': [{'message': {'content': json.dumps(answer)}}]}
        response = json.dumps(result).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(response)))
        self.end_headers()
        self.wfile.write(response)


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.app = Server(0)
        self.model = ThreadingHTTPServer(('127.0.0.1', 0), ModelStub)
        self.model.calls = []
        self.addCleanup(self.app.server_close)
        self.addCleanup(self.model.server_close)
        for server in (self.app, self.model):
            threading.Thread(target=server.serve_forever, daemon=True).start()
            self.addCleanup(server.shutdown)
        self.endpoint = f'http://127.0.0.1:{self.app.server_port}'
        self.client = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.settings = {
            'base_url': f'http://127.0.0.1:{self.model.server_port}/v1',
            'model': 'mock-chat', 'embedding_model': 'mock-embed', 'api_key': 'test-key',
        }

    def request(self, path, payload=None):
        data = None if payload is None else json.dumps(payload).encode()
        request = urllib.request.Request(self.endpoint + path, data=data, headers={'Content-Type': 'application/json'})
        with self.client.open(request, timeout=5) as response:
            return json.load(response) if response.headers.get_content_type() == 'application/json' else response.read()

    def submit(self, **options):
        request = {'document': {'name': '稿件.txt', 'text': CLAIM}, 'library': {'text': LIBRARY, 'format': 'json'},
                   'candidate_limit': 10, **options}
        job = self.request('/api/jobs', request)['id']
        path = f'/api/jobs/{job}'
        for _ in range(100):
            summary = self.request(path)
            if summary['status'] != 'running':
                self.assertEqual(summary['status'], 'ready', summary.get('error'))
                return path, summary
            time.sleep(.03)
        self.fail('任务没有完成')

    def test_model_connection_hybrid_review_and_export(self):
        self.assertTrue(self.request('/api/model-test', {'model': self.settings})['ok'])
        path, summary = self.submit(model=self.settings, auto_accept=True)
        self.assertEqual(summary['retrieval'], '关键词 + 向量')
        self.assertEqual(summary['rows'][0]['status'], 'approved')
        audit = self.request(path + '/export/json')
        self.assertEqual(audit['endnotes'][0]['quote'], QUOTE)
        self.assertNotIn('test-key', str(audit))
        self.assertIn(('/v1/chat/completions', 'Bearer test-key'), self.model.calls)
        self.assertIn(('/v1/embeddings', 'Bearer test-key'), self.model.calls)
        self.assertIn(QUOTE, self.request(path + '/export/html').decode())

    def test_offline_server_rejects_remote_model_configuration(self):
        self.assertIs(self.request('/api/health')['offline'], True)
        remote = {**self.settings, 'base_url': 'https://example.invalid/v1'}
        with self.assertRaises(urllib.error.HTTPError) as failure:
            self.request('/api/model-test', {'model': remote})
        with failure.exception as response:
            self.assertEqual(response.code, 400)
            self.assertIn('离线模式', json.load(response)['error'])
        self.assertEqual(self.model.calls, [])

    def test_manual_review_and_digest(self):
        path, summary = self.submit()
        self.assertEqual(summary['rows'][0]['status'], 'pending')
        detail = self.request(path + '/claims/C1')
        candidate = next(candidate for candidate in detail['candidates'] if candidate['quote'].startswith(QUOTE))
        selected = {'window_id': candidate['id'], 'first': 1, 'last': 2}
        reviewed = self.request(path + '/claims/C1/review', {'action': 'approve', 'selections': [selected]})
        self.assertEqual(reviewed['evidence'][0]['quote'], QUOTE)
        self.assertTrue(self.request(path + '/export/docx').startswith(b'PK'))

    def test_word_attachments_preview_review_and_export(self):
        files = [
            word_file('A', '交通资料.docx', [('Title', '交通报道'), ('', QUOTE)]),
            word_file('B', '其他资料.docx', [('', '海州市一季度登记100件新商标。')]),
        ]
        entries = self.request('/api/word-sources/preview', {'files': files})['entries']
        self.assertEqual(len(entries), 2)
        path, summary = self.submit(library_files=files, word_metadata={entries[0]['key']: {'publisher': '海州日报'}})
        self.assertEqual(summary['source_count'], 2)
        detail = self.request(path + '/claims/C1')
        candidate = next(item for item in detail['candidates'] if item['quote'] == QUOTE)
        selected = {'window_id': candidate['id'], 'first': 1, 'last': 2}
        self.request(path + '/claims/C1/review', {'action': 'approve', 'selections': [selected]})
        audit = self.request(path + '/export/json')
        self.assertEqual(audit['endnotes'][0]['location']['first_paragraph'], 2)
        html = self.request(path + '/export/html').decode()
        self.assertIn('交通资料.docx', html)
        self.assertIn('链接未提供', html)
        self.assertIn(QUOTE, html)


if __name__ == '__main__':
    unittest.main()
