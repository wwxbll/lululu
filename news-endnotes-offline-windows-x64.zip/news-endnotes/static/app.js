const $ = id => document.getElementById(id);
const state = {
  library: [], nextFile: 0, wordOverrides: {}, wordRequest: 0, document: null,
  job: null, jobId: null, selected: null, offline: true,
  request: 0, choices: [], timer: null,
};
const statusLabels = {
  pending: '待复核', suggested: '建议采纳', insufficient: '依据不足', conflict: '存在冲突',
  approved: '已采纳', skipped: '无需引用', ignored: '已略过',
};
const providers = {
  review: ['', '', '可先使用内置关键词检索，直接复核候选原文。'],
  ollama: ['http://127.0.0.1:11434/v1', 'qwen3:8b', '先启动 Ollama，并填写已下载的模型名称。'],
  lmstudio: ['http://127.0.0.1:1234/v1', '', '先在 LM Studio 启动本机服务，并填写已加载的模型名称。'],
  api: ['https://api.openai.com/v1', '', '开始匹配后，待核验句子和候选片段会发送到所填服务。启用 Embedding 时也会发送待索引片段。'],
};
const mediaClasses = {full: '全文', publisher_summary: '发布方摘要', summary: '二次或未知来源摘要'};

function element(tag, className, text) {
  const result = document.createElement(tag);
  if (className) result.className = className;
  if (text !== undefined) result.textContent = text;
  return result;
}

function setMessage(target, text, error = false) {
  target.textContent = text;
  target.classList.toggle('error', error);
}

async function request(path, payload) {
  const options = payload ? {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload),
  } : {};
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || '请求失败');
  return data;
}

function jobPath(suffix = '') {
  return '/api/jobs/' + state.jobId + suffix;
}

function modelSettings() {
  if ($('provider').value === 'review') return null;
  return {
    base_url: $('base-url').value.trim(), model: $('model-name').value.trim(),
    api_key: $('api-key').value.trim(), embedding_model: $('embedding').value.trim(),
  };
}

function selectProvider() {
  const mode = $('provider').value;
  const [url, model, hint] = providers[mode];
  $('model-fields').hidden = mode === 'review';
  $('base-url').value = url;
  $('base-url').disabled = mode === 'review';
  $('model-name').value = model;
  $('api-key').value = '';
  $('embedding').value = '';
  $('auto-accept').checked = false;
  $('provider-hint').textContent = hint;
  setMessage($('model-message'), '');
}

async function utf8(file) {
  try {
    return new TextDecoder('utf-8', {fatal: true}).decode(await file.arrayBuffer());
  } catch {
    throw new Error('文件不是有效的 UTF-8。请转换编码后重新导入。');
  }
}

function base64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = () => reject(new Error('无法读取文稿文件。'));
    reader.readAsDataURL(file);
  });
}

function showDocument(value) {
  state.document = value;
  $('document-chip').hidden = !value;
  $('document-name').textContent = value ? value.name : '';
  $('document-text').hidden = Boolean(value);
}

function showLibrary() {
  const list = $('library-files');
  list.hidden = !state.library.length;
  list.replaceChildren();
  $('library-name').textContent = state.library.length
    ? '继续添加 · 已选 ' + state.library.length + ' 个文件' : '添加素材文件';
  for (const file of state.library) {
    const item = element('li');
    const remove = element('button', 'link', '移除');
    remove.type = 'button';
    remove.setAttribute('aria-label', '移除 ' + file.name);
    remove.addEventListener('click', () => {
      state.library = state.library.filter(entry => entry.key !== file.key);
      for (const key of Object.keys(state.wordOverrides)) {
        if (key.startsWith(file.key + ':')) delete state.wordOverrides[key];
      }
      showLibrary();
    });
    item.append(element('span', '', file.name), remove);
    list.append(item);
  }
  previewWord();
}

async function previewWord() {
  const files = state.library.filter(file => file.format === 'docx');
  $('word-options').hidden = !files.length;
  const sequence = ++state.wordRequest;
  const entries = $('word-entries');
  entries.replaceChildren();
  $('word-summary').textContent = '检查和补填 Word 素材的来源信息';
  setMessage($('word-message'), '');
  if (!files.length) return;
  setMessage($('word-message'), '正在读取 Word 素材…');
  try {
    const data = await request('/api/word-sources/preview', {files, split_word_headings: $('split-word-headings').checked});
    if (sequence !== state.wordRequest) return;
    $('word-summary').textContent += '（' + data.entries.length + ' 条）';
    setMessage($('word-message'), '来源信息可留空，尾注会记录 Word 文件和段落。');
    for (const entry of data.entries) {
      const editor = element('fieldset', 'word-entry');
      editor.append(element('legend', '', entry.file_name + ' · 正文从第 ' + entry.first_paragraph + ' 段起'));
      const grid = element('div', 'word-entry-grid');
      for (const [key, title] of [['title', '素材标题'], ['publisher', '来源'], ['date', '发布日期'], ['url', '原文 URL']]) {
        const label = element('label', '', title);
        const input = element('input');
        input.type = key === 'url' ? 'url' : 'text';
        input.value = state.wordOverrides[entry.key]?.[key] ?? entry[key] ?? '';
        input.addEventListener('input', () => {
          state.wordOverrides[entry.key] ||= {};
          state.wordOverrides[entry.key][key] = input.value;
        });
        label.append(input);
        grid.append(label);
      }
      editor.append(grid);
      entries.append(editor);
    }
  } catch (error) {
    if (sequence === state.wordRequest) setMessage($('word-message'), error.message, true);
  }
}

function visibleRows() {
  if (!state.job) return [];
  const filter = $('queue-filter').value;
  return state.job.rows.filter(row => filter === 'all' ||
    (filter === 'approved' && row.status === 'approved') ||
    (filter === 'pending' && !['approved', 'skipped', 'ignored'].includes(row.status)));
}

function statusBadge(status) {
  const badge = element('span', 'status', statusLabels[status] || status);
  badge.dataset.status = status;
  return badge;
}

function renderQueue() {
  const list = $('queue-list');
  list.replaceChildren();
  const rows = visibleRows();
  if (!rows.length) list.append(element('p', 'empty', '这个筛选条件下暂无陈述。'));
  for (const row of rows) {
    const item = element('button', 'queue-item');
    item.type = 'button';
    item.setAttribute('aria-current', String(row.id === state.selected));
    item.append(statusBadge(row.status), element('span', '', row.text));
    item.addEventListener('click', () => openClaim(row.id));
    list.append(item);
  }
}

function renderSummary(job) {
  state.job = job;
  $('summary').hidden = false;
  const ready = job.status === 'ready';
  const approved = job.rows.filter(row => row.status === 'approved').length;
  const pending = job.rows.filter(row => !['approved', 'skipped', 'ignored'].includes(row.status)).length;
  const status = ready
    ? [job.name, job.source_count + ' 条素材', job.retrieval, approved + ' 条已采纳', pending + ' 条待处理'].join(' · ')
    : job.error || job.phase + ' · ' + job.rows.length + ' / ' + job.total + ' 句';
  setMessage($('job-message'), status, job.status === 'failed');
  $('progress').max = job.total;
  $('progress').value = job.rows.length;
  $('progress').hidden = job.status !== 'running';
  $('run').disabled = job.status === 'running';
  const notices = job.warnings.slice();
  if (job.duplicate_count) notices.push('已归并 ' + job.duplicate_count + ' 条重复原文。');
  $('warnings').hidden = !notices.length;
  $('warnings').textContent = notices.join(' ');
  $('workspace').hidden = !ready;
  $('exports').hidden = !ready;
  if (!ready) return;
  for (const format of ['docx', 'html', 'json']) {
    const link = $('export-' + format);
    link.hidden = !approved && format !== 'json';
    link.href = jobPath('/export/' + format);
  }
  renderQueue();
  if (!state.selected && visibleRows().length) openClaim(visibleRows()[0].id);
  else if (!state.selected) $('review').replaceChildren(
    element('p', 'empty', '当前筛选下没有陈述。可切换到全部或导出结果。'),
  );
}

async function refreshJob() {
  const id = state.jobId;
  if (!id) return;
  try {
    const job = await request(jobPath());
    if (id !== state.jobId) return;
    renderSummary(job);
    if (job.status === 'running') state.timer = setTimeout(refreshJob, 1000);
  } catch (error) {
    if (id !== state.jobId) return;
    sessionStorage.removeItem('citation-job');
    setMessage($('form-message'), error.message, true);
    $('run').disabled = false;
  }
}

async function openClaim(claimId) {
  state.selected = claimId;
  const sequence = ++state.request;
  renderQueue();
  $('review').replaceChildren(element('p', 'empty', '正在读取候选原文…'));
  try {
    const detail = await request(jobPath('/claims/' + claimId));
    if (sequence === state.request) renderDetail(detail);
  } catch (error) {
    if (sequence === state.request) $('review').replaceChildren(element('p', 'empty error', error.message));
  }
}

function actionButton(label, className, listener) {
  const button = element('button', 'button ' + className, label);
  button.type = 'button';
  button.addEventListener('click', listener);
  return button;
}

function renderDetail(detail, message = '') {
  const review = $('review');
  state.choices = [];
  const comparison = element('div', 'comparison');
  const left = element('section', 'review-column');
  left.append(element('h3', '', '文稿陈述'), statusBadge(detail.status), element('p', 'claim', detail.text));
  if (detail.context) {
    const context = element('details', 'hint');
    context.append(element('summary', '', '查看上文'), element('p', 'context', detail.context));
    left.append(context);
  }
  left.append(element('p', 'hint', detail.reason));
  if (detail.flags.length) left.append(element('p', 'notice', detail.flags.join(' ')));
  const right = element('section', 'review-column');
  right.append(element('h3', '', '候选原文'));
  const searchInput = element('input');
  searchInput.type = 'search';
  searchInput.placeholder = '补充搜索词';
  searchInput.maxLength = 400;
  searchInput.setAttribute('aria-label', '补充搜索词');
  const search = element('form', 'search');
  const searchButton = element('button', 'button secondary', '搜索');
  search.append(searchInput, searchButton);
  right.append(search);
  if (!detail.candidates.length) right.append(element('p', 'empty', '暂未召回候选。试试素材标题、实体名称或数字。'));
  const candidates = element('div', 'candidate-list');
  for (const candidate of detail.candidates) candidates.append(renderCandidate(candidate, detail.evidence));
  right.append(candidates);

  const bar = element('div', 'review-actions');
  const result = element('span', 'hint', message);
  result.setAttribute('role', 'status');
  const confirm = actionButton('确认所选摘录', 'primary', () => update('approve'));
  const dismiss = actionButton('无需尾注', 'secondary', () => update('dismiss'));
  const reopen = actionButton('退回复核', 'secondary', () => update('reopen'));
  bar.append(confirm, dismiss, reopen, result);
  reopen.hidden = !['approved', 'ignored', 'skipped'].includes(detail.status);
  comparison.append(left, right);
  review.replaceChildren(comparison, bar);

  search.addEventListener('submit', async event => {
    event.preventDefault();
    const query = searchInput.value.trim();
    if (!query) return;
    const sequence = state.request;
    searchButton.disabled = true;
    try {
      const updated = await request(jobPath('/claims/' + detail.id + '/search'), {query});
      if (sequence === state.request) {
        renderDetail(updated, '补充搜索找到 ' + updated.search_count + ' 个候选。');
      }
    } catch (error) {
      setMessage(result, error.message, true);
    } finally {
      searchButton.disabled = false;
    }
  });

  async function update(action) {
    const selections = state.choices.filter(choice => choice.checked.checked).map(choice => ({
      window_id: choice.id, first: Number(choice.first.value), last: Number(choice.last.value),
    }));
    if (action === 'approve' && (!selections.length || selections.length > 3)) {
      setMessage(result, '请选择 1–3 段可引用原文。', true);
      return;
    }
    const sequence = state.request;
    for (const button of [confirm, dismiss, reopen]) button.disabled = true;
    try {
      const updated = await request(jobPath('/claims/' + detail.id + '/review'), {action, selections});
      if (sequence === state.request) renderDetail(updated, action === 'approve' ? '已采纳，可导出。' : '已更新复核状态。');
      await refreshJob();
    } catch (error) {
      setMessage(result, error.message, true);
    } finally {
      for (const button of [confirm, dismiss, reopen]) button.disabled = false;
    }
  }
}

function renderCandidate(candidate, evidence) {
  const saved = evidence.find(item => item.window_id === candidate.id);
  const available = candidate.source.kind !== 'summary';
  const card = element('article', 'candidate');
  const title = element('label', 'candidate-title');
  const checked = element('input');
  checked.type = 'checkbox';
  checked.disabled = !available;
  checked.checked = Boolean(saved && available);
  title.append(checked, element('strong', '', candidate.source.title));
  const meta = element('p', 'hint candidate-meta', [candidate.source.publisher, candidate.source.date,
    candidate.source.file_name, mediaClasses[candidate.source.kind]].filter(Boolean).join(' · '));
  const excerpt = element('p', 'quote');
  const footer = element('div', 'candidate-footer');
  const link = state.offline
    ? element('span', 'hint', candidate.source.url)
    : element('a', '', '原始链接');
  link.hidden = !candidate.source.url;
  if (!state.offline && candidate.source.url) {
    link.href = candidate.source.url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
  }
  const first = element('select');
  const last = element('select');
  first.setAttribute('aria-label', '摘录起始句');
  last.setAttribute('aria-label', '摘录结束句');
  for (let i = 1; i <= candidate.sentences.length; i += 1) {
    first.add(new Option('第 ' + i + ' 句起', i));
    last.add(new Option('至第 ' + i + ' 句', i));
  }
  first.value = saved ? saved.first : 1;
  last.value = saved ? saved.last : candidate.sentences.length;
  first.hidden = last.hidden = candidate.sentences.length === 1 || !available;
  first.addEventListener('change', () => {
    if (Number(first.value) > Number(last.value)) last.value = first.value;
    updateExcerpt();
  });
  last.addEventListener('change', () => {
    if (Number(last.value) < Number(first.value)) first.value = last.value;
    updateExcerpt();
  });
  const full = actionButton('原文定位', 'secondary', () => openSource(candidate.id, Number(first.value), Number(last.value)));
  footer.append(first, last, full, link);
  card.append(title, meta, excerpt, footer);
  state.choices.push({id: candidate.id, checked, first, last});
  updateExcerpt();
  return card;

  function updateExcerpt() {
    const start = candidate.ranges[Number(first.value) - 1][0];
    const end = candidate.ranges[Number(last.value) - 1][1];
    excerpt.textContent = Array.from(candidate.quote).slice(start, end).join('');
  }
}

async function openSource(windowId, first, last) {
  const dialog = $('source-dialog');
  $('source-title').textContent = '素材全文';
  $('source-meta').textContent = '';
  $('source-content').textContent = '正在定位原文…';
  dialog.showModal();
  try {
    const data = await request(jobPath('/sources/' + windowId));
    const start = data.ranges[first - 1][0], end = data.ranges[last - 1][1];
    const characters = Array.from(data.text);
    const mark = element('mark', '', characters.slice(start, end).join(''));
    $('source-title').textContent = data.source.title;
    const location = data.locations[first - 1];
    const lastLocation = data.locations[last - 1];
    const position = location && lastLocation
      ? location.file_name + ' · 第 ' + location.first_paragraph +
        (location.first_paragraph === lastLocation.last_paragraph ? '' : '–' + lastLocation.last_paragraph) + ' 段'
      : '';
    $('source-meta').textContent = [data.source.publisher, data.source.date, position].filter(Boolean).join(' · ');
    $('source-content').replaceChildren(characters.slice(0, start).join(''), mark, characters.slice(end).join(''));
    if (dialog.open) mark.scrollIntoView({block: 'center'});
  } catch (error) {
    $('source-content').textContent = error.message;
  }
}

$('provider').addEventListener('change', selectProvider);
$('split-word-headings').addEventListener('change', previewWord);
$('queue-filter').addEventListener('change', () => {
  const rows = visibleRows();
  if (rows.some(row => row.id === state.selected)) renderQueue();
  else if (rows.length) openClaim(rows[0].id);
  else {
    state.selected = null;
    state.request += 1;
    renderQueue();
    $('review').replaceChildren(element('p', 'empty', '当前筛选下没有陈述。'));
  }
});
for (const label of document.querySelectorAll('label[tabindex="0"]')) {
  label.addEventListener('keydown', event => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    $(label.htmlFor).click();
  });
}

$('document-file').addEventListener('change', async event => {
  const file = event.target.files[0];
  if (!file) return;
  try {
    if (file.size > 12 * 1024 * 1024) throw new Error('单份文稿文件请控制在 12 MB 以内。');
    const data = /\.docx$/i.test(file.name) ? {base64: await base64(file)} : {text: await utf8(file)};
    showDocument({name: file.name, ...data});
    setMessage($('form-message'), '');
  } catch (error) {
    setMessage($('form-message'), error.message, true);
  } finally {
    event.target.value = '';
  }
});
$('remove-document').addEventListener('click', () => {
  showDocument(null);
  $('document-text').focus();
});

$('source-file').addEventListener('change', async event => {
  const files = Array.from(event.target.files);
  if (!files.length) return;
  try {
    if (files.length + state.library.length > 40) throw new Error('请选择 1–40 个素材文件。');
    const added = await Promise.all(files.map(async file => {
      const format = file.name.split('.').pop().toLowerCase();
      if (!['docx', 'json', 'csv', 'tsv'].includes(format)) throw new Error('请选择 DOCX、JSON、CSV 或 TSV。');
      if (file.size > 16 * 1024 * 1024) throw new Error('「' + file.name + '」超过 16 MB。');
      const contents = format === 'docx' ? {base64: await base64(file)} : {text: await utf8(file)};
      return {key: 'upload-' + (++state.nextFile), name: file.name, format, ...contents};
    }));
    state.library.push(...added);
    showLibrary();
    setMessage($('form-message'), '');
  } catch (error) {
    setMessage($('form-message'), error.message, true);
  } finally {
    event.target.value = '';
  }
});

$('load-example').addEventListener('click', async () => {
  $('load-example').disabled = true;
  try {
    const responses = await Promise.all([fetch('/example.txt'), fetch('/example.json')]);
    if (responses.some(response => !response.ok)) throw new Error('示例读取失败。');
    const [text, data] = await Promise.all(responses.map(response => response.text()));
    showDocument(null);
    $('document-text').value = text;
    state.library = [{key: 'example', format: 'json', name: '示例素材库.json', text: data}];
    state.wordOverrides = {};
    showLibrary();
    setMessage($('form-message'), '已载入示例。');
  } catch (error) {
    setMessage($('form-message'), error.message, true);
  } finally {
    $('load-example').disabled = false;
  }
});

$('test-model').addEventListener('click', async () => {
  const button = $('test-model');
  button.disabled = true;
  setMessage($('model-message'), '正在连接…');
  try {
    await request('/api/model-test', {model: modelSettings()});
    setMessage($('model-message'), '连接和 JSON 响应正常。');
  } catch (error) {
    setMessage($('model-message'), error.message, true);
  } finally {
    button.disabled = false;
  }
});

$('job-form').addEventListener('submit', async event => {
  event.preventDefault();
  const file = state.document || {name: '粘贴文稿.txt', text: $('document-text').value};
  if ((!file.text?.trim() && !file.base64) || !state.library.length) {
    setMessage($('form-message'), '请同时提供文稿和素材库。', true);
    return;
  }
  $('run').disabled = true;
  setMessage($('form-message'), '正在提交…');
  try {
    const model = modelSettings();
    const {id} = await request('/api/jobs', {
      document: file, library_files: state.library, model,
      split_word_headings: $('split-word-headings').checked, word_metadata: state.wordOverrides,
      auto_accept: Boolean(model && $('auto-accept').checked),
      candidate_limit: Number($('candidate-limit').value),
    });
    clearTimeout(state.timer);
    sessionStorage.setItem('citation-job', id);
    state.jobId = id;
    state.selected = null;
    state.request += 1;
    $('queue-filter').value = 'pending';
    $('workspace').hidden = true;
    setMessage($('form-message'), '');
    await refreshJob();
    $('summary').scrollIntoView({block: 'nearest', behavior: 'smooth'});
  } catch (error) {
    setMessage($('form-message'), error.message, true);
    $('run').disabled = false;
  }
});

async function initialize() {
  try {
    const health = await request('/api/health');
    state.offline = health.offline !== false;
    $('run-mode').textContent = state.offline ? '离线模式' : '在线 API 可用';
    $('remote-provider').hidden = $('remote-provider').disabled = state.offline;
  } catch {
    setMessage($('form-message'), '无法连接本机服务，请检查启动窗口。', true);
  }
  state.jobId = sessionStorage.getItem('citation-job');
  if (state.jobId) refreshJob();
}

initialize();
