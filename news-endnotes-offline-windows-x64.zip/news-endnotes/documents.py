import base64
import html
import io
import re
import zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from engine import can_cite, verify_record


WORD = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
REL = 'http://schemas.openxmlformats.org/package/2006/relationships'
OFFICE_REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
CONTENT = 'http://schemas.openxmlformats.org/package/2006/content-types'
ET.register_namespace('w', WORD)
INVALID_XML = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff\ud800-\udfff]')


def w(name):
    return f'{{{WORD}}}{name}'


@dataclass(frozen=True)
class WordParagraph:
    number: int
    text: str
    role: str
    links: tuple


def read_word(encoded):
    try:
        data = base64.b64decode(encoded, validate=True)
        with zipfile.ZipFile(io.BytesIO(data)) as package:
            body = read_xml(package, 'word/document.xml').find(w('body'))
            if body is None:
                raise ValueError('未读取到 Word 正文。')
            styles = {}
            relationships = {}
            if 'word/styles.xml' in package.namelist():
                for style in read_xml(package, 'word/styles.xml').iter(w('style')):
                    role = paragraph_role(style.find(w('name')), style.find(f'{w("pPr")}/{w("outlineLvl")}'))
                    if role:
                        styles[style.get(w('styleId'))] = role
            if 'word/_rels/document.xml.rels' in package.namelist():
                for rel in read_xml(package, 'word/_rels/document.xml.rels'):
                    if rel.get('Type', '').endswith('/hyperlink'):
                        relationships[rel.get('Id')] = rel.get('Target')
            paragraphs = []
            for index, paragraph in enumerate(body.iter(w('p')), 1):
                style = paragraph.find(f'{w("pPr")}/{w("pStyle")}')
                level = paragraph.find(f'{w("pPr")}/{w("outlineLvl")}')
                role = paragraph_role(style, level)
                if not role and style is not None:
                    role = styles.get(style.get(w('val')), '')
                urls = (relationships.get(link.get(f'{{{OFFICE_REL}}}id'))
                        for link in paragraph.iter(w('hyperlink')))
                paragraphs.append(WordParagraph(index, paragraph_text(paragraph), role,
                                                tuple(url for url in urls if url)))
            return paragraphs
    except (KeyError, TypeError, ET.ParseError, zipfile.BadZipFile, RuntimeError) as error:
        raise ValueError('无法读取 DOCX，请用 Word 另存为普通 .docx 文档。') from error


def read_xml(package, filename):
    entry = package.getinfo(filename)
    if entry.file_size > 8 * 1024 * 1024:
        raise ValueError('Word 文本或样式 XML 超过 8 MB。')
    xml = package.read(entry)
    if b'<!DOCTYPE' in xml.replace(b'\x00', b''):
        raise ValueError('Word 文件含不支持的 XML 声明。')
    return ET.fromstring(xml)


def paragraph_role(style, level):
    name = re.sub(r'\s', '', style.get(w('val'), '')).lower() if style is not None else ''
    if (level is not None and level.get(w('val')) == '0') or name in ('heading1', '标题1'):
        return 'heading'
    if name in ('title', '标题'):
        return 'title'
    return ''


def extract_text(document):
    if not isinstance(document, dict):
        raise ValueError('请上传或粘贴一篇文档。')
    name = document.get('name', 'document.txt')
    if not isinstance(name, str):
        raise ValueError('文档文件名无效。')
    ext = Path(name).suffix.lower()
    if ext == '.docx':
        text = '\n'.join(paragraph.text for paragraph in read_word(document.get('base64')))
    elif ext in ('.txt', '.md', ''):
        text = document.get('text', '')
    else:
        raise ValueError('文档格式应为 DOCX、TXT 或 Markdown。')
    if not isinstance(text, str) or not text.strip():
        raise ValueError('文档正文为空。')
    if len(text) > 150000 or INVALID_XML.search(text):
        raise ValueError('正文需少于 150,000 字符，并采用有效的 Unicode 文本。')
    return text


def paragraph_text(paragraph):
    parts = []

    def collect(element):
        for child in element:
            if child.tag in (w('p'), w('del'), w('moveFrom'), w('pPr'), w('txbxContent'), w('drawing')):
                continue
            if child.tag == w('t'):
                parts.append(child.text or '')
            elif child.tag == w('tab'):
                parts.append('\t')
            elif child.tag in (w('br'), w('cr')):
                parts.append('\n')
            else:
                collect(child)

    collect(paragraph)
    return ''.join(parts)


def report(index, document, rows):
    endnotes = []
    marks = defaultdict(list)
    for row in rows:
        if row['status'] != 'approved':
            continue
        evidence = verify_record(index, row['evidence'])
        if not can_cite(evidence):
            raise ValueError('有一条已选证据不可作为正式引文。')
        if document[row['start']:row['end']] != row['text']:
            raise ValueError('正文锚点与待导出文档不一致。')
        for item in evidence:
            number = len(endnotes) + 1
            endnotes.append({**item, 'number': number, 'claim_id': row['id']})
            marks[row['end']].append(number)
    return endnotes, marks


def segments(text, marks):
    start = 0
    for end, numbers in sorted(marks.items()):
        yield text[start:end], numbers
        start = end
    yield text[start:], []


def entry_label(entry):
    source = entry['source']
    return f"《{source['title']}》｜{source['publisher'] or '来源未提供'}｜{source['date'] or '日期未提供'}"


def location_label(entry):
    location = entry.get('location')
    if not location:
        return ''
    first, last = location['first_paragraph'], location['last_paragraph']
    position = f'第 {first} 段' if first == last else f'第 {first}–{last} 段'
    return f"素材文件：{location['file_name']}，{position}"


def quote_label(entry):
    return '依据原文（发布方摘要）' if entry['source']['kind'] == 'publisher_summary' else '依据原文'


def render_html(document, endnotes, marks):
    esc = html.escape
    body = []
    notes = []
    for text, numbers in segments(document, marks):
        body.append(esc(text))
        for n in numbers:
            body.append(f'<sup><a id="ref-{n}" href="#note-{n}">{n}</a></sup>')
    for entry in endnotes:
        n = entry['number']
        url = esc(entry['source']['url'], quote=True)
        link = f'<a href="{url}">{url}</a>' if url else '链接未提供'
        location = f'<div>{esc(location_label(entry))}</div>' if entry.get('location') else ''
        notes.append(f'<li id="note-{n}">{esc(entry_label(entry))}｜{link}{location}'
                     f'<div class="quote">{quote_label(entry)}：“{esc(entry["quote"])}”</div>'
                     f'<a href="#ref-{n}">返回正文</a></li>')
    end = '<h2>尾注</h2><ol>' + ''.join(notes) + '</ol>' if notes else ''
    return ('<!doctype html><html lang="zh-CN"><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            '<title>文档与尾注</title><style>body{margin:3rem auto;padding:0 1rem;max-width:52rem;'
            'font:17px/1.8 system-ui;color:#192a2e}main,.quote{white-space:pre-wrap;overflow-wrap:anywhere}'
            'li{padding:.5rem 0;overflow-wrap:anywhere}sup+sup{margin-inline-start:.2em}</style>'
            '<main>' + ''.join(body) + '</main>' + end + '</html>').encode('utf-8')


def xml(element):
    return ET.tostring(element, encoding='utf-8', xml_declaration=True)


def sub(parent, name, **attributes):
    return ET.SubElement(parent, w(name), {w(key): str(value) for key, value in attributes.items()})


def word_text(paragraph, text):
    if not text:
        return
    run = sub(paragraph, 'r')
    for part in re.split(r'(\r\n|\n|\r|\t)', text):
        if part in ('\r\n', '\n', '\r'):
            sub(run, 'br')
        elif part == '\t':
            sub(run, 'tab')
        elif part:
            node = sub(run, 't')
            node.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
            node.text = part


def reference(paragraph, tag, **attributes):
    run = sub(paragraph, 'r')
    sub(sub(run, 'rPr'), 'vertAlign', val='superscript')
    sub(run, tag, **attributes)


def render_docx(document, endnotes, marks):
    root = ET.Element(w('document'))
    body = sub(root, 'body')
    paragraph = sub(body, 'p')
    for text, numbers in segments(document, marks):
        for index, line in enumerate(re.split(r'\r\n|\n|\r', text)):
            if index:
                paragraph = sub(body, 'p')
            word_text(paragraph, line)
        for number in numbers:
            reference(paragraph, 'endnoteReference', id=number)
    sect = sub(body, 'sectPr')
    properties = sub(sect, 'endnotePr')
    sub(properties, 'pos', val='docEnd')
    sub(properties, 'numFmt', val='decimal')

    endnote_root = ET.Element(w('endnotes'))
    for entry in endnotes:
        note = sub(endnote_root, 'endnote', id=entry['number'])
        paragraph = sub(note, 'p')
        reference(paragraph, 'endnoteRef')
        word_text(paragraph, f" {entry_label(entry)}｜{entry['source']['url'] or '链接未提供'}")
        if entry.get('location'):
            word_text(sub(note, 'p'), location_label(entry))
        paragraph = sub(note, 'p')
        word_text(paragraph, f'{quote_label(entry)}：“{entry["quote"]}”')

    content_types = ET.Element('Types', xmlns=CONTENT)
    for extension, content_type in (
        ('rels', 'application/vnd.openxmlformats-package.relationships+xml'), ('xml', 'application/xml'),
    ):
        ET.SubElement(content_types, 'Default', Extension=extension, ContentType=content_type)
    ET.SubElement(content_types, 'Override', PartName='/word/document.xml',
                  ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml')
    if endnotes:
        ET.SubElement(content_types, 'Override', PartName='/word/endnotes.xml',
                      ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml')
    package_rels = ET.Element('Relationships', xmlns=REL)
    ET.SubElement(package_rels, 'Relationship', Id='rId1', Type=OFFICE_REL + '/officeDocument',
                  Target='word/document.xml')
    document_rels = ET.Element('Relationships', xmlns=REL)
    ET.SubElement(document_rels, 'Relationship', Id='rId1', Type=OFFICE_REL + '/endnotes', Target='endnotes.xml')

    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as package:
        package.writestr('[Content_Types].xml', xml(content_types))
        package.writestr('_rels/.rels', xml(package_rels))
        package.writestr('word/document.xml', xml(root))
        if endnotes:
            package.writestr('word/_rels/document.xml.rels', xml(document_rels))
            package.writestr('word/endnotes.xml', xml(endnote_root))
    return stream.getvalue()
